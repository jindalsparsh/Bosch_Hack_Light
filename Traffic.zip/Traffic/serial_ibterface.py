#!/usr/bin/python  
import serial as sl 
import time  
import datetime  
  
ser = sl.Serial('/dev/tty.usbmodem14101',9600)   
ser.write(b'0') #Send data to arduino. Activate arduino read pin and write to serial  
